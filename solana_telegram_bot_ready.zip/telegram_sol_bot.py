
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler

TOKEN = "8191430523:AAHDafXxkRlbsURs7bM6tnt9OZFo_XQG2nw"

PHANTOM_WEBAPP_URL = "https://yourusername.github.io/solana-phantom-connect/phantom-connect.html"

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("🔗 ربط المحفظة (Phantom)", web_app=WebAppInfo(url=PHANTOM_WEBAPP_URL))],
        [InlineKeyboardButton("🟢 تشغيل البوت", callback_data="start_bot")],
        [InlineKeyboardButton("🔴 إيقاف البوت", callback_data="stop_bot")],
        [InlineKeyboardButton("💰 شراء يدوي", callback_data="manual_buy")],
        [InlineKeyboardButton("💸 بيع يدوي", callback_data="manual_sell")],
        [InlineKeyboardButton("📦 تحديد حجم العقد", callback_data="contract_size")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("👋 أهلاً بك! اختر من القائمة:", reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if query.data == "start_bot":
        await query.edit_message_text("✅ تم تشغيل البوت.")
    elif query.data == "stop_bot":
        await query.edit_message_text("🛑 تم إيقاف البوت.")
    elif query.data == "manual_buy":
        await query.edit_message_text("💰 الرجاء إرسال رابط العملة لشرائها يدويًا.")
    elif query.data == "manual_sell":
        await query.edit_message_text("💸 تم تنفيذ البيع اليدوي.")
    elif query.data == "contract_size":
        keyboard = [
            [InlineKeyboardButton("0.1 SOL", callback_data="size_0.1")],
            [InlineKeyboardButton("0.01 SOL", callback_data="size_0.01")],
            [InlineKeyboardButton("0.001 SOL", callback_data="size_0.001")],
            [InlineKeyboardButton("0.0001 SOL", callback_data="size_0.0001")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📦 اختر حجم العقد:", reply_markup=reply_markup)
    elif query.data.startswith("size_"):
        size = query.data.split("_")[1]
        await query.edit_message_text(f"📦 تم تحديد حجم العقد: {size} SOL")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
